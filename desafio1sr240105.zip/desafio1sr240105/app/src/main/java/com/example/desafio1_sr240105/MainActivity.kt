package com.example.desafio1_sr240105

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var montoTotal: EditText
    private lateinit var numeroPersonas: EditText
    private lateinit var propinaPersonalizada: EditText
    private lateinit var radioGroup: RadioGroup
    private lateinit var switchIVA: Switch
    private lateinit var resultado: TextView
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        montoTotal = findViewById(R.id.montoTotal)
        numeroPersonas = findViewById(R.id.numeroPersonas)
        propinaPersonalizada = findViewById(R.id.etPropinaPersonalizada)
        radioGroup = findViewById(R.id.radioGroup)
        switchIVA = findViewById(R.id.switchIVA)
        resultado = findViewById(R.id.resultado)
        btnCalcular = findViewById(R.id.btncalcular)
        btnLimpiar = findViewById(R.id.btnlimpiar)

        // Mostrar campo de propina personalizada solo si se selecciona "Otro"
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            propinaPersonalizada.visibility =
                if (checkedId == R.id.radioPersonalizado) View.VISIBLE else View.GONE
        }

        btnCalcular.setOnClickListener { calcularPropina() }
        btnLimpiar.setOnClickListener { limpiar() }
    }

    private fun calcularPropina() {
        val montoStr = montoTotal.text.toString()
        val personasStr = numeroPersonas.text.toString()

        if (montoStr.isEmpty() || personasStr.isEmpty()) {
            mostrarMensaje("Ingrese monto y número de personas")
            return
        }

        val monto = montoStr.toDoubleOrNull()
        val personas = personasStr.toIntOrNull()

        if (monto == null || personas == null || monto <= 0 || personas <= 0) {
            mostrarMensaje("Valores inválidos")
            return
        }

        val porcentaje = when (radioGroup.checkedRadioButtonId) {
            R.id.radio10 -> 10.0
            R.id.radio15 -> 15.0
            R.id.radio20 -> 20.0
            R.id.radioPersonalizado -> {
                val personalizada = propinaPersonalizada.text.toString().toDoubleOrNull()
                if (personalizada == null || personalizada < 0) {
                    mostrarMensaje("Propina personalizada inválida")
                    return
                }
                personalizada
            }
            else -> {
                mostrarMensaje("Seleccione un porcentaje")
                return
            }
        }

        val propina = monto * porcentaje / 100
        val iva = if (switchIVA.isChecked) monto * 0.16 else 0.0
        val total = monto + propina + iva
        val porPersona = total / personas

        resultado.text = """
            Propina: $${"%.2f".format(propina)}
            IVA: $${"%.2f".format(iva)}
            Total: $${"%.2f".format(total)}
            Por Persona: $${"%.2f".format(porPersona)}
        """.trimIndent()
    }

    private fun limpiar() {
        montoTotal.setText("")
        numeroPersonas.setText("")
        propinaPersonalizada.setText("")
        radioGroup.clearCheck()
        switchIVA.isChecked = false
        propinaPersonalizada.visibility = View.GONE
        resultado.text = "Resultado:"
    }

    private fun mostrarMensaje(texto: String) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show()
    }
}
