package com.example.desafio1_sr240105

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var montoTotal: EditText
    private lateinit var numeroPersonas: EditText
    private lateinit var propinaPersonalizada: EditText
    private lateinit var radioGroup: RadioGroup
    private lateinit var switchIVA: Switch
    private lateinit var resultado: TextView
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar vistas
        montoTotal = findViewById(R.id.montoTotal)
        numeroPersonas = findViewById(R.id.numeroPersonas)
        propinaPersonalizada = findViewById(R.id.etPropinaPersonalizada)
        radioGroup = findViewById(R.id.radioGroup)
        switchIVA = findViewById(R.id.switchIVA)
        resultado = findViewById(R.id.resultado)
        btnCalcular = findViewById(R.id.btncalcular)
        btnLimpiar = findViewById(R.id.btnlimpiar)

        // Mostrar campo personalizado solo si se selecciona "Otro"
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            propinaPersonalizada.visibility = if (checkedId == R.id.radioPersonalizado) View.VISIBLE else View.GONE
        }

        btnCalcular.setOnClickListener { calcularPropina() }
        btnLimpiar.setOnClickListener { limpiar() }
    }

    private fun calcularPropina() {
        val monto = montoTotal.text.toString().toDoubleOrNull()
        val personas = numeroPersonas.text.toString().toIntOrNull()

        if (monto == null || personas == null || monto <= 0 || personas <= 0) {
            mostrarMensaje("Ingrese monto y número de personas válidos")
            return
        }

        // Obtener porcentaje
        val porcentaje = when (radioGroup.checkedRadioButtonId) {
            R.id.radio10 -> 10.0
            R.id.radio15 -> 15.0
            R.id.radio20 -> 20.0
            R.id.radioPersonalizado -> propinaPersonalizada.text.toString().toDoubleOrNull() ?: -1.0
            else -> -1.0
        }

        if (porcentaje < 0) {
            mostrarMensaje("Seleccione un porcentaje válido")
            return
        }

        // Cálculos básicos
        val propina = monto * porcentaje / 100
        val iva = if (switchIVA.isChecked) monto * 0.16 else 0.0
        val total = monto + propina + iva
        val porPersona = total / personas

        // Mostrar resultado sin interpolación, concatenando strings
        val textoResultado = "Propina: $" + String.format("%.2f", propina) + "\n" +
                "IVA: $" + String.format("%.2f", iva) + "\n" +
                "Total: $" + String.format("%.2f", total) + "\n" +
                "Por Persona: $" + String.format("%.2f", porPersona)

        resultado.text = textoResultado
    }

    private fun limpiar() {
        montoTotal.text.clear()
        numeroPersonas.text.clear()
        propinaPersonalizada.text.clear()
        radioGroup.clearCheck()
        switchIVA.isChecked = false
        propinaPersonalizada.visibility = View.GONE
        resultado.text = "Resultado:"
    }

    private fun mostrarMensaje(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }
}
